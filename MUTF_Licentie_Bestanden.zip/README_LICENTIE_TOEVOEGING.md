## Licentie

- De broncode in deze repository valt onder de [MIT-licentie](LICENSE).
- De documentatie (`docs/Multicolor_Tekenvoorstel.pdf`) valt onder een [Creative Commons BY-NC 4.0-licentie](https://creativecommons.org/licenses/by-nc/4.0/deed.nl).

Je mag dit materiaal gebruiken voor niet-commerciële doeleinden, mits correcte bronvermelding.
Voor commercieel gebruik neem contact op met de auteurs.
